package com.example.pocketassistant

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private enum class Screen { HOME, CONFIRM, ABOUT }
private enum class Panel { NONE, DRAFT, DIAL }

@Composable
fun PocketAssistantApp() {
    val context = LocalContext.current
    val prefs = remember { LocalPrefs(context) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var pending by rememberSaveable { mutableStateOf<Pending?>(null) }
    var status by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Surface(Modifier.fillMaxSize()) {
        Box(Modifier.safeDrawingPadding()) {
            val current = pending
            when {
                screen == Screen.ABOUT -> AboutScreen(
                    onClearPrefs = {
                        prefs.clear()
                        status = "Local preferences cleared."
                    },
                    onBack = { screen = Screen.HOME },
                )

                screen == Screen.CONFIRM && current != null -> ConfirmScreen(
                    pending = current,
                    onCancel = {
                        pending = null
                        status = "Cancelled. Nothing was sent or dialed."
                        screen = Screen.HOME
                    },
                    onSuccess = { message ->
                        if (current is Pending.Message && current.rememberApp) {
                            prefs.defaultApp = current.app
                        }
                        pending = null
                        status = message
                        screen = Screen.HOME
                    },
                )

                else -> HomeScreen(
                    prefs = prefs,
                    status = status,
                    onStatus = { status = it },
                    onReview = {
                        pending = it
                        status = ""
                        screen = Screen.CONFIRM
                    },
                    onAbout = { screen = Screen.ABOUT },
                )
            }
        }
    }
}

@Composable
private fun StatusText(text: String) {
    if (text.isNotEmpty()) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { liveRegion = LiveRegionMode.Polite },
        )
    }
}

@Composable
private fun HomeScreen(
    prefs: LocalPrefs,
    status: String,
    onStatus: (String) -> Unit,
    onReview: (Pending) -> Unit,
    onAbout: () -> Unit,
) {
    var command by rememberSaveable { mutableStateOf("") }
    var panel by rememberSaveable { mutableStateOf(Panel.NONE) }
    var draftApp by rememberSaveable { mutableStateOf(prefs.defaultApp ?: MessagingApp.WHATSAPP) }
    var draftText by rememberSaveable { mutableStateOf("") }
    var rememberApp by rememberSaveable { mutableStateOf(false) }
    var dialNumber by rememberSaveable { mutableStateOf("") }

    fun runCommand(text: String) {
        when (val result = CommandParser.parse(text)) {
            is ParseResult.Draft -> onReview(Pending.Message(result.app, result.text))
            is ParseResult.Dial -> onReview(Pending.Dial(result.number))
            ParseResult.Cancel -> {
                command = ""
                draftText = ""
                dialNumber = ""
                panel = Panel.NONE
                onStatus("Draft cleared.")
            }
            is ParseResult.NeedsClarification -> onStatus(result.question)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        when (result.resultCode) {
            Activity.RESULT_OK -> {
                val heard = result.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (heard.isNullOrBlank()) {
                    onStatus("I didn’t catch that. Try again, or type your command.")
                } else {
                    command = heard
                    runCommand(heard)
                }
            }
            Activity.RESULT_CANCELED ->
                onStatus("Voice input cancelled. You can type your command instead.")
            RecognizerIntent.RESULT_NO_MATCH ->
                onStatus("I couldn’t understand that. Try again, or type your command.")
            RecognizerIntent.RESULT_NETWORK_ERROR ->
                onStatus("Speech recognition on this phone needs a connection right now. Please type your command instead.")
            else ->
                onStatus("Voice input failed. Please type your command instead.")
        }
    }

    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            onStatus("No speech recognition service was found on this phone. Please type your command.")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Pocket Assistant", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = command,
            onValueChange = { command = it },
            label = { Text("Type a command") },
            placeholder = { Text("Message WhatsApp I’m on my way") },
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = { runCommand(command) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) { Text("Run command") }

        Button(
            onClick = { startVoice() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
        ) { Text("🎤  Tap to talk") }

        StatusText(status)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { panel = if (panel == Panel.DRAFT) Panel.NONE else Panel.DRAFT },
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
            ) { Text("Draft a message") }
            OutlinedButton(
                onClick = { panel = if (panel == Panel.DIAL) Panel.NONE else Panel.DIAL },
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
            ) { Text("Open dialer") }
        }

        when (panel) {
            Panel.DRAFT -> {
                Text("App", style = MaterialTheme.typography.titleMedium)
                MessagingApp.entries.forEach { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .selectable(
                                selected = draftApp == app,
                                onClick = { draftApp = app },
                                role = Role.RadioButton,
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = draftApp == app, onClick = null)
                        Text(app.label, modifier = Modifier.padding(start = 12.dp))
                    }
                }
                OutlinedTextField(
                    value = draftText,
                    onValueChange = { draftText = it },
                    label = { Text("Message text") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = rememberApp, onCheckedChange = { rememberApp = it })
                    Text(
                        "Remember this app as my default (saved on this phone only)",
                        modifier = Modifier.padding(start = 12.dp),
                    )
                }
                Button(
                    onClick = {
                        if (draftText.isBlank()) onStatus("Please enter the message text.")
                        else onReview(Pending.Message(draftApp, draftText.trim(), rememberApp))
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("Review draft") }
            }

            Panel.DIAL -> {
                OutlinedTextField(
                    value = dialNumber,
                    onValueChange = { dialNumber = it },
                    label = { Text("Phone number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { runCommand("call $dialNumber") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("Review number") }
            }

            Panel.NONE -> Unit
        }

        OutlinedButton(
            onClick = onAbout,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) { Text("About & Privacy") }
    }
}

@Composable
private fun ConfirmScreen(
    pending: Pending,
    onCancel: () -> Unit,
    onSuccess: (String) -> Unit,
) {
    val context = LocalContext.current
    var error by rememberSaveable { mutableStateOf("") }
    var copied by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Please confirm", style = MaterialTheme.typography.headlineMedium)

        when (pending) {
            is Pending.Message -> {
                Text("App: ${pending.app.label}", style = MaterialTheme.typography.titleMedium)
                Text("Message:")
                Card(Modifier.fillMaxWidth()) {
                    Text(pending.text, modifier = Modifier.padding(16.dp))
                }
                Text(pending.app.note, style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(
                    onClick = {
                        val cm = context.getSystemService(ClipboardManager::class.java)
                        cm.setPrimaryClip(ClipData.newPlainText("Draft message", pending.text))
                        copied = true
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("Copy text") }
                if (copied) StatusText("Text copied to the clipboard.")
            }

            is Pending.Dial -> {
                Text("Number:")
                Text(pending.number, style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Your dialer will open with this number filled in. Nothing is called until you press the call button there.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        StatusText(error)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f).heightIn(min = 52.dp),
            ) { Text("Cancel") }
            Button(
                onClick = {
                    val problem = when (pending) {
                        is Pending.Message -> Handoff.shareMessage(context, pending.app, pending.text)
                        is Pending.Dial -> Handoff.openDialer(context, pending.number)
                    }
                    if (problem != null) {
                        error = problem
                    } else {
                        onSuccess(
                            when (pending) {
                                is Pending.Message ->
                                    "Opened ${pending.app.label}. Review the draft and send it there."
                                is Pending.Dial ->
                                    "Opened the dialer. Press the call button there if you want to call."
                            }
                        )
                    }
                },
                modifier = Modifier.weight(1f).heightIn(min = 52.dp),
            ) { Text("Continue") }
        }
    }
}

@Composable
private fun AboutScreen(onClearPrefs: () -> Unit, onBack: () -> Unit) {
    var cleared by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("About & Privacy", style = MaterialTheme.typography.headlineMedium)

        Text("What this app does", style = MaterialTheme.typography.titleMedium)
        Text(
            "It turns a typed or spoken command into a draft message or a phone number, " +
                "shows it to you, and then opens another app for you to finish. " +
                "It never sends a message or places a call by itself."
        )

        Text("What it stores", style = MaterialTheme.typography.titleMedium)
        Text(
            "Only, if you turn it on, your default messaging app (its name, on this phone). " +
                "Message text, phone numbers, call history, voice recordings and transcripts are not saved."
        )

        Text("Permissions", style = MaterialTheme.typography.titleMedium)
        Text(
            "None. There is no internet, microphone, contacts or call permission. " +
                "Voice input opens Android’s own speech-recognition screen, which handles the microphone itself."
        )

        Text("Other apps and services", style = MaterialTheme.typography.titleMedium)
        Text(
            "Android’s speech service (often provided by Google) may process your audio outside this app " +
                "and may need an internet connection, depending on your phone and settings. " +
                "Offline voice is not guaranteed; typing always works. " +
                "Once you continue, WhatsApp, Instagram, Snapchat or your dialer receive the text or number " +
                "and follow their own privacy practices. If you tap “Copy text”, the text sits on the clipboard."
        )

        Text("Limits", style = MaterialTheme.typography.titleMedium)
        Text(
            "Apps decide for themselves whether they accept shared text. " +
                "WhatsApp usually does; Instagram and Snapchat may not."
        )

        OutlinedButton(
            onClick = {
                onClearPrefs()
                cleared = true
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) { Text("Clear local preferences") }
        if (cleared) StatusText("Local preferences cleared.")

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
        ) { Text("Back") }
    }
}
