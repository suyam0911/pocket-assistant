package com.example.pocketassistant

/**
 * Small, transparent command parser. Pure Kotlin (no Android classes) so it is easy to unit test.
 *
 * Supported:
 *   message <whatsapp|instagram|snapchat> <text>
 *   call <number>
 *   cancel | clear
 * Anything else, or anything incomplete, produces a clarification question instead of a guess.
 */
object CommandParser {

    // Longer aliases first so the most specific one wins.
    private val appAliases: List<Pair<String, MessagingApp>> = listOf(
        "whatsapp" to MessagingApp.WHATSAPP,
        "whats app" to MessagingApp.WHATSAPP,
        "instagram" to MessagingApp.INSTAGRAM,
        "insta" to MessagingApp.INSTAGRAM,
        "snapchat" to MessagingApp.SNAPCHAT,
        "snap" to MessagingApp.SNAPCHAT,
    )

    private val numberChars = Regex("^\\+?[0-9 ()\\-.]+$")

    fun parse(input: String): ParseResult {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return ParseResult.NeedsClarification(
                "Type or say a command, for example “Message WhatsApp I’m on my way” or “Call 555 0100”."
            )
        }

        val bare = trimmed.trimEnd('.', '!', '?').trim().lowercase()
        if (bare == "cancel" || bare == "clear") return ParseResult.Cancel

        val parts = trimmed.split(Regex("\\s+"), limit = 2)
        val verb = parts[0].lowercase().trimEnd(',', ':', '.')
        val rest = parts.getOrNull(1)?.trim().orEmpty()

        return when (verb) {
            "message" -> parseMessage(rest)
            "call" -> parseCall(rest)
            else -> ParseResult.NeedsClarification(
                "I didn’t understand that. Try “Message WhatsApp …”, “Call …”, or “Cancel”."
            )
        }
    }

    private fun parseMessage(rest: String): ParseResult {
        if (rest.isEmpty()) {
            return ParseResult.NeedsClarification(
                "Which app? Say “Message WhatsApp”, “Message Instagram” or “Message Snapchat”, then your text."
            )
        }
        val lower = rest.lowercase()
        val match = appAliases.firstOrNull { (alias, _) ->
            lower == alias ||
                lower.startsWith("$alias ") ||
                lower.startsWith("$alias,") ||
                lower.startsWith("$alias:")
        } ?: return ParseResult.NeedsClarification(
            "I couldn’t tell which app you meant. I support WhatsApp, Instagram and Snapchat."
        )

        val text = rest.substring(match.first.length).trimStart(' ', ',', ':').trim()
        if (text.isEmpty()) {
            return ParseResult.NeedsClarification("What should the ${match.second.label} message say?")
        }
        return ParseResult.Draft(match.second, text)
    }

    private fun parseCall(rest: String): ParseResult {
        if (rest.isEmpty()) {
            return ParseResult.NeedsClarification("Which number should I show in the dialer?")
        }
        if (!numberChars.matches(rest)) {
            return ParseResult.NeedsClarification(
                "I couldn’t read that as a phone number. Please use digits, e.g. “Call +1 555 0100”. Contact names aren’t supported yet."
            )
        }
        val digits = rest.filter { it.isDigit() }
        if (digits.length !in 3..15) {
            return ParseResult.NeedsClarification(
                "That number has ${digits.length} digits. Phone numbers have 3 to 15 digits, please check it."
            )
        }
        val normalized = (if (rest.startsWith("+")) "+" else "") + digits
        return ParseResult.Dial(normalized)
    }
}
