package com.example.pocketassistant

import android.content.Context

/**
 * The only thing this app ever stores: the user's optional default messaging app.
 * No message text, numbers, call history, audio or transcripts are saved.
 */
class LocalPrefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("pocket_assistant_prefs", Context.MODE_PRIVATE)

    var defaultApp: MessagingApp?
        get() = sp.getString(KEY_DEFAULT_APP, null)
            ?.let { name -> MessagingApp.entries.firstOrNull { it.name == name } }
        set(value) {
            sp.edit().apply {
                if (value == null) remove(KEY_DEFAULT_APP) else putString(KEY_DEFAULT_APP, value.name)
            }.apply()
        }

    fun clear() {
        sp.edit().clear().apply()
    }

    private companion object {
        const val KEY_DEFAULT_APP = "default_app"
    }
}
