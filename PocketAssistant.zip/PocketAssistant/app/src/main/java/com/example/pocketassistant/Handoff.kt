package com.example.pocketassistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Hands a confirmed action to another app. Nothing is ever sent or called from here:
 * the target app / dialer opens and the user finishes the action there.
 * Each function returns null on success or a human-readable error message.
 */
object Handoff {

    fun shareMessage(context: Context, app: MessagingApp, text: String): String? {
        if (context.packageManager.getLaunchIntentForPackage(app.packageName) == null) {
            return "${app.label} doesn’t appear to be installed on this phone."
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage(app.packageName) // explicit target: never silently switch apps
        }
        val cannotReceive =
            "${app.label} can’t receive shared text from other apps. You can copy the text and paste it yourself."
        return try {
            context.startActivity(intent)
            null
        } catch (e: ActivityNotFoundException) {
            cannotReceive
        } catch (e: SecurityException) {
            cannotReceive
        }
    }

    fun openDialer(context: Context, number: String): String? {
        // ACTION_DIAL only pre-fills the dialer. It needs no CALL_PHONE permission and never dials.
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
        return try {
            context.startActivity(intent)
            null
        } catch (e: ActivityNotFoundException) {
            "No dialer app was found on this phone."
        }
    }
}
