# Pocket Assistant (starter project)

A small, offline-first Android app (Kotlin + Jetpack Compose) that turns a typed or spoken command into a
**draft message** or a **phone number**, shows you a confirmation screen, and then opens WhatsApp /
Instagram / Snapchat or the system dialer. **You** press send or call. The app never does it for you.

> Status: this project was written but **not built or run** by the author (no Android SDK or network
> was available). Expect to fix small issues on first sync. The command-parser unit tests are included but
> have not been executed.

## Assumptions
- `minSdk 24` (Android 7.0), `targetSdk`/`compileSdk 34`. Your Oppo A54 runs Android 10 or later, so it is covered.
- AGP 8.5.2, Kotlin 2.0.20, Gradle 8.7, JDK 17 (bundled with recent Android Studio).
- Placeholder launcher icon (the system default). Replace it via *File → New → Image Asset*.
- Package name `com.example.pocketassistant`; change it before publishing anywhere.

## Build and run
1. Install a recent Android Studio (Koala 2024.1 or newer).
2. *File → Open…* and choose this folder. Let Gradle sync (needs internet once, to download dependencies).
   - `gradle/wrapper/gradle-wrapper.properties` is included, but `gradlew` and `gradle-wrapper.jar` are not.
     Android Studio downloads Gradle 8.7 from the properties file. If it complains, install Gradle 8.7 and run
     `gradle wrapper` in this folder, or pick *Use Gradle from: gradle-wrapper.properties* in Settings → Build → Gradle.
3. On your phone: *Settings → About phone →* tap *Build number* 7 times, then *Developer options → USB debugging*.
4. Connect by USB, accept the debugging prompt, pick the phone in Android Studio and press **Run ▶**.
5. Unit tests: right-click `app/src/test` → *Run Tests*, or `./gradlew test`.

## How it works
| File | Role |
|---|---|
| `CommandParser.kt` | Pure-Kotlin parser: `message <app> <text>`, `call <number>`, `cancel`/`clear`. Incomplete or odd input returns a clarification question. |
| `Models.kt` | `MessagingApp`, `Pending` (action awaiting confirmation), `ParseResult`. |
| `Handoff.kt` | `ACTION_SEND` with an explicit package for messaging apps; `ACTION_DIAL` for the dialer. Returns an error message if the app is missing or refuses. |
| `LocalPrefs.kt` | Stores one optional preference (default app). Includes `clear()`. |
| `Ui.kt` | Home, Confirm and About/Privacy screens (state-based, no navigation library). |

## Privacy and battery
- No `INTERNET`, `RECORD_AUDIO`, contacts, call or location permissions. No services, receivers, polling or wake locks.
- Voice uses Android's built-in speech dialog (`RecognizerIntent`), opened only when you tap the mic. That system
  service handles the microphone, so this app doesn't need the permission. It may process audio off-device and may need
  internet depending on your phone. Typing always works.
- Nothing is stored except the optional default app. `android:allowBackup="false"`.

## Known limitations
- Recipients are chosen inside the target app; the command syntax has no "to <name>".
- WhatsApp accepts shared text. Instagram and Snapchat often don't accept plain text from other apps, so the app reports
  that and offers **Copy text** instead of switching apps silently.
- Spoken numbers must be recognised as digits; contact names aren't supported (no Contacts permission).
- Speech recognition language/accuracy depends on the phone's speech service.

## Ideas for later (each needs a privacy discussion first)
- Optional contact picker using `ACTION_PICK` (no broad Contacts permission needed).
- Saved message templates (stored locally, clearly labelled).
