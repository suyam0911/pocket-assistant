package com.example.pocketassistant

import java.io.Serializable

enum class MessagingApp(val label: String, val packageName: String, val note: String) {
    WHATSAPP(
        "WhatsApp", "com.whatsapp",
        "WhatsApp will open its chat picker with your text ready. You choose the recipient and press send yourself."
    ),
    INSTAGRAM(
        "Instagram", "com.instagram.android",
        "Instagram may not accept plain text shared from other apps. If it refuses, copy the text and paste it yourself."
    ),
    SNAPCHAT(
        "Snapchat", "com.snapchat.android",
        "Snapchat may not accept plain text shared from other apps. If it refuses, copy the text and paste it yourself."
    ),
}

/** An action waiting for the user's explicit confirmation. Serializable so it survives rotation. */
sealed class Pending : Serializable {
    data class Message(
        val app: MessagingApp,
        val text: String,
        val rememberApp: Boolean = false,
    ) : Pending()

    data class Dial(val number: String) : Pending()
}

sealed class ParseResult {
    data class Draft(val app: MessagingApp, val text: String) : ParseResult()
    data class Dial(val number: String) : ParseResult()
    data object Cancel : ParseResult()
    data class NeedsClarification(val question: String) : ParseResult()
}
