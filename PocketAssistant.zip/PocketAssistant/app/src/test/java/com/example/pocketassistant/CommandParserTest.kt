package com.example.pocketassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    @Test fun messageWhatsApp_parsesAppAndText() {
        val r = CommandParser.parse("Message WhatsApp I'm on my way")
        assertEquals(ParseResult.Draft(MessagingApp.WHATSAPP, "I'm on my way"), r)
    }

    @Test fun messageAliases_work() {
        assertEquals(ParseResult.Draft(MessagingApp.INSTAGRAM, "hi"), CommandParser.parse("message insta hi"))
        assertEquals(ParseResult.Draft(MessagingApp.SNAPCHAT, "hi"), CommandParser.parse("message snap hi"))
        assertEquals(ParseResult.Draft(MessagingApp.WHATSAPP, "hi"), CommandParser.parse("message whats app hi"))
    }

    @Test fun messagePreservesTextCasing() {
        val r = CommandParser.parse("MESSAGE whatsapp Meet at SOHO")
        assertEquals(ParseResult.Draft(MessagingApp.WHATSAPP, "Meet at SOHO"), r)
    }

    @Test fun messageWithColonOrComma_stripsSeparator() {
        assertEquals(ParseResult.Draft(MessagingApp.WHATSAPP, "hello"), CommandParser.parse("message whatsapp: hello"))
        assertEquals(ParseResult.Draft(MessagingApp.WHATSAPP, "hello"), CommandParser.parse("message whatsapp, hello"))
    }

    @Test fun messageWithoutApp_asksForClarification() {
        assertTrue(CommandParser.parse("message") is ParseResult.NeedsClarification)
    }

    @Test fun messageWithUnknownApp_asksForClarification() {
        assertTrue(CommandParser.parse("message telegram hello") is ParseResult.NeedsClarification)
    }

    @Test fun messageWithoutText_asksForClarification() {
        assertTrue(CommandParser.parse("message whatsapp") is ParseResult.NeedsClarification)
        assertTrue(CommandParser.parse("message whatsapp   ") is ParseResult.NeedsClarification)
    }

    @Test fun appNamePrefixOfWord_isNotMatched() {
        // "snapshot" must not be read as "snap" + "shot"
        assertTrue(CommandParser.parse("message snapshot hello") is ParseResult.NeedsClarification)
    }

    @Test fun call_parsesAndNormalizesNumber() {
        assertEquals(ParseResult.Dial("5550100"), CommandParser.parse("Call 555 0100"))
        assertEquals(ParseResult.Dial("+15550100"), CommandParser.parse("call +1 (555) 0100"))
        assertEquals(ParseResult.Dial("5551234567"), CommandParser.parse("call 555-123-4567"))
    }

    @Test fun callWithoutNumber_asksForClarification() {
        assertTrue(CommandParser.parse("call") is ParseResult.NeedsClarification)
    }

    @Test fun callWithName_asksForClarification() {
        assertTrue(CommandParser.parse("call mom") is ParseResult.NeedsClarification)
    }

    @Test fun callWithTooFewOrTooManyDigits_asksForClarification() {
        assertTrue(CommandParser.parse("call 12") is ParseResult.NeedsClarification)
        assertTrue(CommandParser.parse("call 1234567890123456") is ParseResult.NeedsClarification)
    }

    @Test fun cancelAndClear_returnCancel() {
        assertEquals(ParseResult.Cancel, CommandParser.parse("cancel"))
        assertEquals(ParseResult.Cancel, CommandParser.parse("  Clear. "))
        assertEquals(ParseResult.Cancel, CommandParser.parse("CANCEL!"))
    }

    @Test fun cancelInsideMessage_isNotACancel() {
        assertEquals(
            ParseResult.Draft(MessagingApp.WHATSAPP, "cancel"),
            CommandParser.parse("message whatsapp cancel"),
        )
    }

    @Test fun emptyOrUnknownInput_asksForClarification() {
        assertTrue(CommandParser.parse("") is ParseResult.NeedsClarification)
        assertTrue(CommandParser.parse("   ") is ParseResult.NeedsClarification)
        assertTrue(CommandParser.parse("order a pizza") is ParseResult.NeedsClarification)
    }
}
